# Software-Engineering-Processes-group7
Assignment 2: Repository Analysis and Usage

# Table of contents
* [Analysis of repository airy](#analysis-of-repository-airy)
  * <details> 
    <summary> questions</summary>

    * [Q1](#q1)
    * [Q2](#q2)
    * [Q3](#q3)
    * [Q4](#q4)
    * [Q5](#q5)
    * [Q6](#q6)
    * [Q7](#q7)
    * [Q8](#q8)
    
</details>

* [Analysis of repository artipie](#analysis-of-repository-artipie)
  * <details> 
    <summary> questions</summary>
  
    * [Q1](#q1-1)
    * [Q2](#q2-1)
    * [Q3](#q3-1)
    * [Q4](#q4-1)
    * [Q5](#q5-1)
    * [Q6](#q6-1)
    * [Q7](#q7-1)
    * [Q8](#q8-1)

</details>

* [Report of individual contributions](#report-of-individual-contributions)


### (Repository usage)
GP1) Each commit is an atomic change;

GP2) Each commit message is clear, follows a pattern, and is traceable (i.e., it is linked to an issue or a pull request that is linked to an issue)

GP3) Issues should be created to split the work among the group’s members, and assignments should be done;

GP4) Every issue should be closed once it’s addressed through a pull request;

GP5) Every commit on the main branch should only be done through the merge of a pull request;

GP6) Every pull request should be merged by a different group member than who submitted it.


## Task 1 (repository analysis)
<details>
<summary> Summary of all the questions</summary>

Q1) Describe, with your own words, what the project is about. Also, include in such a description the history of the project in terms of age, number of commits in the main branch, and number of collaborators.

Q2) What are the practices in terms of commit messages (consider only commits on the main branch)?

Q3) How are the issues organized?

Q4) Are there instructions on how to contribute to the project? If yes, explain them.

Q5) What automated checks do exist on a commit pushed to the main branch?

Q6) In the context of pull requests, what automated checks are done (consider checks on commits and comments posted in the pull requests by automated tools and bots)?

Q7) How are the release notes organized?

Q8) What is the license of the project? Explain if it’s permissive or restrictive.
</details>


## *Analysis of repository airy*
#### **Q1**
> Describe, with your own words, what the project is about. Also, include in such a description the history of the 
> project in terms of age, number of commits in the main branch, and number of collaborators.


This project is a framework that trains Machine Learning models to stream historical and real-time data.
The infrastructure of Airy is built around Apache Kafka and can process lots of event from various sources.
You can for instance use Whatsapp messages as a source and forward that data to an application made by a company.
That company can now use the data in a efficient manner.

On the Insights tab, it is shown that the project was created on September 6th, 2020. The main branch of the repository
has a total of 2927 commits, and there are a total of 24 contributors to the project.

#### **Q2**
> What are the practices in terms of commit messages (consider only commits on the main branch)?

The commit messages contain a simple sentence that describe the changes made in the commit.
For instance: "Fix new Whatsapp ingestion payload structure" and "Fix broken links in the docs".
The commits are also traceable because there is a suffix in every commit that refers to which issue it is from.
Some commits involve updating dependencies, and are performed by a bot account. These commits are generated
automatically when a update is detected regarding dependencies. They do however follow the same dependencies as
the other commits.

#### **Q3** 
>How are the issues organized?


In the project, Issues are displayed with labels that indicate their topic. For example, there may be labels
indicating that an issue is a bug that needs to be fixed or that a discussion is needed about a certain feature.
Issues labeled as “bug” also include a bug report that explains the nature of the bug and when it occurs.
Some issues may be assigned to specific collaborators for resolution. Additionally, the project uses milestones
to track progress towards specific outcomes by showing which issues contribute to achieving them.

#### **Q4**
>Are there instructions on how to contribute to the project? If yes, explain them.

On the main page of the GitHub repository for the project, there is a brief explanation on how to contribute.
The project suggests that good entry points for new contributors are issues labeled with the “gardening” or
“good first patch” tags. For more detailed information on contributing, there is a link to a file called
“contributing-to-airy.md”. The project uses Bazel to build the application and recommends downloading Bazelisk.
Gazelle is used to manage golang-based projects and dependencies within the code. To test images at runtime,
a local instance can be created in Minicube. Contributors must be aware of these necessities before they start
working on the project. The project has established conventions that must be followed in order for contributions
to be accepted, including specific formatting for branch names. Contributors for instance need to follow the
same style of commits as they have. And the description field must use kebab case.

#### **Q5**
> What automated checks do exist on a commit pushed to the main branch?

The workflow that is created to check the commits requests is called `CI`. The workflow essentially checks if the
current branch is a main, develop, or release branch. if it is it uploads the airy binary to S3 and publishes helm
charts. if the branch is main which it is in this case it publishes the http-client and chat-plugin libraries to npm

When a commit is pushed to the main branch, a series of tests/checks are performed on the commit to check if it builds
successfully. The bot used to check the commit is called *Dependabot*. The operating system used to perform these checks 
is Ubuntu, and Bazel is used as the build tool. After all the necessary dependencies are installed with: <br>
`run yarn install`,
the checks are performed with `ShellCheck`. When the tests are completed and passed, the check starts cleaning up 
everything. After all orphan processes are cleaned up, the check is terminated.


#### **Q6**
> In the context of pull requests, what automated checks are done (consider checks on commits and comments posted in the pull requests by automated tools and bots)?

When pull requests are done from the main the "TimonVS/pr-labeler-action" is automatically runned which labels requests 
when they are opened. The GITHUB_TOKEN is used to authenticate the action which results into the label being added on 
behalf of the user.


#### **Q7**
> How are the release notes organized?

The release notes are organized into several sections. The first section is the version number of the release. The next section is titled changes which lists the
changes made in this release, with each change identified by a number in square brackets and a short description of the change. The following sections are titles
Features, Bug Fixes, Documentation, and Maintenance. Where each section lists the respective features. Bug fixes, documentation updates, and maintenance tasks including
this release. Every section is formatted the same as the section Changes. With a number identifying the change and a brief description. The last section of the release
page contains links to download Airy to different operating systems, and a link to the source code.

#### **Q8** 
> What is the license of the project? Explain if it’s permissive or restrictive.

The project is licensed under the Apache License, Version 2.0, which is a permissive open-source license.
It grants users extensive rights to use, modify, and distribute the software. Users can reproduce,
prepare derivative works of, publicly display, and publicly perform the software. The license also allows
sublicensing and distribution in both source and object forms. Users are required to provide a copy of the license and
retain copyright, patent, trademark, and attribution notices in derivative works. The license includes patent grants to
protect users from potential patent infringements.



## *Analysis of repository artipie*

#### **Q1** 
> Describe, with your own words, what the project is about. Also, include in such a description the history of the project in terms of age, number of commits in the main branch, and number of collaborators.

Artipie is a binary artifact management tool, similar to Artifactory, Nexus, Archiva, ProGet, and many others. 
It is an open-source, horizontally scalable, and database-free project that serves as a versatile binary repository manager. 
It provides developers and organizations with a platform to host, manage, and distribute various types of binary artifacts, 
including software packages, libraries, and dependencies. The project was started in 2020, this makes it 3 years old. 
The total number of commits on the main branch is 2411 all committed by a total of 28 contributors.

#### **Q2**
> What are the practices in terms of commit messages (consider only commits on the main branch)?

Any commit made describes in one short sentence what it does, there can be multiple commits that work up to one functional part of the system. 
After a part of the system has been enhanced, modified, or removed in an arbitrary number of commits a pull request is made by another collaborator. 
This pull request has a number that specifies the commit it will merge in the following syntax: Merge pull request #number from collaborator. However, 
not every commit is clear in how it resolves an issue, as some commits do not specify which issue it solves or targets.

#### **Q3**
>How are the issues organized?

The issues are split into two groups, open and closed. Some issues have labels that specify certain aspects of the issue, 
there are a total of 34 different kinds of labels. Labels can represent different types of issues (bug, enhancement, documentation, 
duplicate, invalid, etc.), priority levels (low, medium, high), quality levels(bad, acceptable, good), and other custom categorizations.

#### **Q4**
>Are there instructions on how to contribute to the project? If yes, explain them.

The GitHub page has a page that shows in steps exactly how to contribute to the project. First you fork the repository, make the changes you have worked on, and send a pull request. The Artipie team will review the changes and apply them to the master branch shortly, 
provided they don't violate the quality standards. In order to contribute there are some preparations one must make, such as running Docker, building a test environment, or using a JDK-11 or Maven 3.2+. After preparations are made, one must follow rules regarding code style, 
pull request style, title and description, how to request a review, and commit style. Some of the main rules are:
*    Code style is enforced by the "qulice" Maven plugin which aggregates multiple rules for "checkstyle" and "PMD".
*    Primary PR rule: it's the responsibility of PR author to bring the changes to the master branch.
*    Title format: <type>[optional scope]: <description>
*    Description provides information about how the problem from title was fixed. It should be a short summary of all changes to increase readability of changes before looking to code, and provide some context.
*    It's recommended to request review from @artipie/maintainers if possible. When the reviewers starts the review it should assign the PR to themselves, when the review is completed and some changes are requested, then it should be assigned back to the author.

#### **Q5**
> What automated checks do exist on a commit pushed to the main branch?

**The automated checks on a commit pushed to the main branch include:
Maven Build: Performs Maven build on Ubuntu and Windows systems. It includes repository checkout, JDK setup, Maven repository caching, and executing the build.
xcop-lint: Performs linting using XCop on Ubuntu system.
pdd-lint: Performs linting using PDD on Ubuntu system.
These checks validate code quality, documentation, and ensure successful Maven builds.**

#### **Q6**
> In the context of pull requests, what automated checks are done (consider checks on commits and comments posted in the pull requests by automated tools and bots)?

on:
push:
branches:

master
pull_request:
branches:
master
This code snippet is on top of the file, which indicates these checks are done on both push and pull requests

#### **Q7**
> How are the release notes organized?

The release notes are organized in reverse chronological order with the latest release at the top of the page. Each release includes a version number, date of release, and a list of changes made in that version2.

#### **Q8**
> What is the license of the project? Explain if it’s permissive or restrictive.

The license of the project is MIT License1. It is a permissive license that allows users to use, modify, distribute, and sell the software without any restrictions. However, it does require users to include a copy of the license in any distribution or modification of the software1.

## Report of individual contributions

The report is divided in a fair manner. Since there was a total of 16 questions and 2 repositories,
we decided to divide the work in a way that each member of the group would answer 4 questions for each.
Ahmed and Sudhir were responsible for the analysis of the repository airy, while Zakaria and Moegiez were responsible
for the analysis of the repository artipie. The issues on GitHub show which questions are answered by which member of 
the group.
